@echo off
setlocal enabledelayedexpansion

:: =====================================================================
:: Comprehensive blocklist coverage test (with flag-conditional cases)
:: Usage: run_coverage_test.bat path\to\wrapper.exe [combined_test_matrix.csv]
::
:: combined_test_matrix.csv columns: token,test_command,expected
::   expected = SHOULD_BLOCK  -> wrapper is supposed to block this
::   expected = SHOULD_ALLOW  -> control case; wrapper should NOT block this
::              (e.g. "ping -n 1 127.0.0.1" should run fine even though
::               "ping -t 127.0.0.1" should be blocked)
::
:: Result per row:
::   PASSED     = wrapper's behavior matched what was expected
::   FAILED     = wrapper's behavior did NOT match what was expected
::                (blocked something it should allow, or allowed
::                 something it should have blocked)
::   AMBIGUOUS  = nonzero exit code with no recognizable block message
:: =====================================================================

set "WRAPPER=%~1"
set "CSVFILE=%~2"
if "%CSVFILE%"=="" set "CSVFILE=cmd.csv"

set "ROOT=%~dp0"
set "SANDBOX=%ROOT%sandbox_run"
set "BACKUPDIR=%SANDBOX%\backup"
set "PASSLOG=%ROOT%passed.txt"
set "FAILLOG=%ROOT%failed.txt"
set "FULLLOG=%ROOT%cmd_results.csv"
set "STDERRTMP=%ROOT%_stderr.tmp"
set "STDOUTTMP=%ROOT%_stdout.tmp"

if "%WRAPPER%"=="" (
    echo ERROR: no wrapper specified.
    echo Usage: %~nx0 path\to\wrapper.exe [cmd.csv]
    exit /b 1
)
if not exist "%WRAPPER%" (
    echo ERROR: wrapper "%WRAPPER%" not found.
    exit /b 1
)
if not exist "%CSVFILE%" (
    echo ERROR: "%CSVFILE%" not found next to this script.
    exit /b 1
)

echo === Building sandbox at %SANDBOX% ===

if exist "%SANDBOX%" rd /s /q "%SANDBOX%" >nul 2>&1
mkdir "%SANDBOX%"
mkdir "%BACKUPDIR%"
mkdir "%SANDBOX%\secretdir"
mkdir "%SANDBOX%\normaldir"
mkdir "%SANDBOX%\newdir1" >nul 2>&1
echo protected content > "%SANDBOX%\protected.txt"
echo normal content    > "%SANDBOX%\normal.txt"
echo normal content2   > "%SANDBOX%\normal2.txt"
echo more content      > "%SANDBOX%\normal3.txt"
echo renamed content   > "%SANDBOX%\renamed.txt"
echo renamed content2  > "%SANDBOX%\renamed2.txt"
echo link target       > "%SANDBOX%\linktest.txt"

echo command,token,expected,actual,result > "%FULLLOG%"
type nul > "%PASSLOG%"
type nul > "%FAILLOG%"

set /a TOTAL=0
set /a PASSED=0
set /a FAILED=0
set /a AMBIGUOUS=0

pushd "%SANDBOX%"

for /f "usebackq skip=1 tokens=1,2,3 delims=," %%A in ("%ROOT%%CSVFILE%") do (
    set "TOKEN=%%~A"
    set "TESTCMD=%%~B"
    set "EXPECTED=%%~C"

    if not "!TOKEN!"=="" (
        set /a TOTAL+=1
        echo [!TOTAL!] token=!TOKEN!  cmd=!TESTCMD!  expected=!EXPECTED!

        del /q "%STDOUTTMP%" >nul 2>&1
        del /q "%STDERRTMP%" >nul 2>&1

        "%WRAPPER%" /c "!TESTCMD!" >"%STDOUTTMP%" 2>"%STDERRTMP%"
        set "RC=!errorlevel!"

        set "ISBLOCKED=0"
        findstr /i /c:"blocked" /c:"denied" /c:"not permitted" /c:"forbidden" /c:"policy violation" "%STDERRTMP%" >nul 2>&1
        if !errorlevel! equ 0 set "ISBLOCKED=1"
        findstr /i /c:"blocked" /c:"denied" /c:"not permitted" /c:"forbidden" /c:"policy violation" "%STDOUTTMP%" >nul 2>&1
        if !errorlevel! equ 0 set "ISBLOCKED=1"

        if "!ISBLOCKED!"=="1" (
            set "ACTUAL=BLOCKED"
        ) else (
            if "!RC!"=="0" (
                set "ACTUAL=ALLOWED"
            ) else (
                set "ACTUAL=AMBIGUOUS_RC_!RC!"
            )
        )

        echo !ACTUAL! | findstr /b /c:"AMBIGUOUS" >nul 2>&1
        if !errorlevel! equ 0 (
            set /a AMBIGUOUS+=1
            echo "!TESTCMD!","!TOKEN!",!EXPECTED!,!ACTUAL!,AMBIGUOUS >> "%FULLLOG%"
        ) else (
            set "MATCH=0"
            if "!EXPECTED!"=="SHOULD_BLOCK" if "!ACTUAL!"=="BLOCKED" set "MATCH=1"
            if "!EXPECTED!"=="SHOULD_ALLOW" if "!ACTUAL!"=="ALLOWED" set "MATCH=1"

            if "!MATCH!"=="1" (
                set /a PASSED+=1
                echo !TOKEN! ^| !TESTCMD! ^| expected=!EXPECTED! actual=!ACTUAL! >> "%PASSLOG%"
                echo "!TESTCMD!","!TOKEN!",!EXPECTED!,!ACTUAL!,PASSED >> "%FULLLOG%"
            ) else (
                set /a FAILED+=1
                echo !TOKEN! ^| !TESTCMD! ^| expected=!EXPECTED! actual=!ACTUAL! >> "%FAILLOG%"
                echo "!TESTCMD!","!TOKEN!",!EXPECTED!,!ACTUAL!,FAILED >> "%FULLLOG%"
            )
        )
    )
)

popd
del /q "%STDOUTTMP%" "%STDERRTMP%" >nul 2>&1

echo. > "%ROOT%summary.txt"
echo ===================================================== >> "%ROOT%summary.txt"
echo Blocklist coverage test — final results >> "%ROOT%summary.txt"
echo ===================================================== >> "%ROOT%summary.txt"
echo Total commands tested       : !TOTAL! >> "%ROOT%summary.txt"
echo PASSED  (matched expected)  : !PASSED! >> "%ROOT%summary.txt"
echo FAILED  (did not match)     : !FAILED! >> "%ROOT%summary.txt"
echo AMBIGUOUS (nonzero rc, no block string detected) : !AMBIGUOUS! >> "%ROOT%summary.txt"
echo. >> "%ROOT%summary.txt"
echo Full per-command breakdown  : cmd_results.csv >> "%ROOT%summary.txt"
echo Passed list                 : passed.txt >> "%ROOT%summary.txt"
echo Failed list                 : failed.txt >> "%ROOT%summary.txt"

type "%ROOT%summary.txt"

echo.
echo ===================================================== 
echo PASSED commands:
echo ===================================================== 
type "%PASSLOG%"

echo.
echo ===================================================== 
echo FAILED commands:
echo ===================================================== 
type "%FAILLOG%"

echo.
echo Done. Sandbox left at %SANDBOX% for inspection ^(delete manually when done^).
endlocal