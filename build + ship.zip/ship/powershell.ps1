param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string]$Wrapper,

    [Parameter(Position = 1)]
    [string]$CsvFile = "powershell_test_matrix.csv"
)

$ErrorActionPreference = "Continue"

# =====================================================================
# PowerShell blocklist coverage test
#
# Usage:
#   .\run_ps_coverage_test.ps1 path\to\wrapper.exe [powershell_test_matrix.csv]
#
# Result per row:
#   PASSED    = wrapper behavior matched expected
#   FAILED    = wrapper behavior did not match expected
#   AMBIGUOUS = nonzero exit code with no recognizable block message
# =====================================================================

$Root      = Split-Path -Parent $MyInvocation.MyCommand.Path
$Sandbox   = Join-Path $Root "sandbox_ps"

$PassLog   = Join-Path $Root "ps_passed.txt"
$FailLog   = Join-Path $Root "ps_failed.txt"
$FullLog   = Join-Path $Root "ps_full_results.csv"
$Summary   = Join-Path $Root "ps_summary.txt"

$StdOutTmp = Join-Path $Root "_ps_stdout.tmp"
$StdErrTmp = Join-Path $Root "_ps_stderr.tmp"

if (!(Test-Path $Wrapper)) {
    Write-Host "ERROR: wrapper '$Wrapper' not found."
    exit 1
}

if (!(Test-Path $CsvFile)) {
    $CsvFile = Join-Path $Root $CsvFile
}

if (!(Test-Path $CsvFile)) {
    Write-Host "ERROR: CSV file '$CsvFile' not found."
    exit 1
}

Write-Host "=== Building sandbox at $Sandbox ==="

if (Test-Path $Sandbox) {
    Remove-Item $Sandbox -Recurse -Force
}

New-Item -ItemType Directory -Path $Sandbox | Out-Null
New-Item -ItemType Directory -Path (Join-Path $Sandbox "secretdir") | Out-Null
New-Item -ItemType Directory -Path (Join-Path $Sandbox "normaldir") | Out-Null

Set-Content (Join-Path $Sandbox "protected.txt") "protected content"
Set-Content (Join-Path $Sandbox "normal.txt") "normal content"
Set-Content (Join-Path $Sandbox "normal2.txt") "normal content2"

"command,token,expected,actual,result" | Set-Content $FullLog
"" | Set-Content $PassLog
"" | Set-Content $FailLog

$Total = 0
$Passed = 0
$Failed = 0
$Ambiguous = 0

Push-Location $Sandbox

$Rows = Import-Csv $CsvFile

foreach ($Row in $Rows) {

    $Token    = $Row.token.Trim()
    $TestCmd  = $Row.test_command.Trim()
    $Expected = $Row.expected.Trim()

    if ([string]::IsNullOrWhiteSpace($Token)) {
        continue
    }

    $Total++

    Write-Host "[$Total] token=$Token expected=$Expected"
    Write-Host "    cmd: $TestCmd"

    Remove-Item $StdOutTmp,$StdErrTmp -Force -ErrorAction SilentlyContinue

    # ---- WRAPPER_INVOKE ----
    # Adjust this if your wrapper accepts PowerShell differently.
    #
    & $Wrapper /c "powershell -NoProfile -Command $TestCmd" `
        1> $StdOutTmp `
        2> $StdErrTmp

    $RC = $LASTEXITCODE

    $StdOut = ""
    $StdErr = ""

    if (Test-Path $StdOutTmp) {
        $StdOut = Get-Content $StdOutTmp -Raw
    }

    if (Test-Path $StdErrTmp) {
        $StdErr = Get-Content $StdErrTmp -Raw
    }

    $BlockedRegex = 'blocked|denied|not permitted|forbidden|policy violation'

    $IsBlocked =
        ($StdOut -match $BlockedRegex) -or
        ($StdErr -match $BlockedRegex)

    if ($IsBlocked) {
        $Actual = "BLOCKED"
    }
    elseif ($RC -eq 0) {
        $Actual = "ALLOWED"
    }
    else {
        $Actual = "AMBIGUOUS_RC_$RC"
    }

    if ($Actual.StartsWith("AMBIGUOUS")) {

        $Ambiguous++

        Add-Content $FullLog "`"$TestCmd`",`"$Token`",$Expected,$Actual,AMBIGUOUS"
        continue
    }

    $Match = $false

    if ($Expected -eq "SHOULD_BLOCK" -and $Actual -eq "BLOCKED") {
        $Match = $true
    }

    if ($Expected -eq "SHOULD_ALLOW" -and $Actual -eq "ALLOWED") {
        $Match = $true
    }

    if ($Match) {

        $Passed++

        Add-Content $PassLog "$Token | $TestCmd | expected=$Expected actual=$Actual"
        Add-Content $FullLog "`"$TestCmd`",`"$Token`",$Expected,$Actual,PASSED"
    }
    else {

        $Failed++

        Add-Content $FailLog "$Token | $TestCmd | expected=$Expected actual=$Actual"
        Add-Content $FullLog "`"$TestCmd`",`"$Token`",$Expected,$Actual,FAILED"
    }
}

Pop-Location

Remove-Item $StdOutTmp,$StdErrTmp -Force -ErrorAction SilentlyContinue

@"
=====================================================
PowerShell blocklist coverage test — final results
=====================================================
Total commands tested       : $Total
PASSED  (matched expected)  : $Passed
FAILED  (did not match)     : $Failed
AMBIGUOUS                   : $Ambiguous

Full breakdown : ps_full_results.csv
Passed list    : ps_passed.txt
Failed list    : ps_failed.txt
"@ | Set-Content $Summary

Get-Content $Summary

Write-Host ""
Write-Host "====================================================="
Write-Host "PASSED commands:"
Write-Host "====================================================="
Get-Content $PassLog

Write-Host ""
Write-Host "====================================================="
Write-Host "FAILED commands:"
Write-Host "====================================================="
Get-Content $FailLog

Write-Host ""
Write-Host "Done. Sandbox left at $Sandbox for inspection." 