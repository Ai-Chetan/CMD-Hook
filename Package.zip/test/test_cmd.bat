@echo off
REM ============================================================================
REM  test_cmd.bat -- cmd.exe layer tests for poc-command-restriction
REM  Run from an injected cmd.exe with poc-host.exe running.
REM  Each command is preceded by an echo identifying what is being tested.
REM ============================================================================

echo.
echo ============================================================
echo  SECTION 1: Direct blocked commands (BLOCK expected)
echo ============================================================

echo [1.1] del - direct file delete
del test_file.txt

echo [1.2] erase - alias for del
erase test_file.txt

echo [1.3] rd - remove directory
rd test_dir

echo [1.4] rmdir - remove directory
rmdir test_dir

echo [1.5] shutdown /s
shutdown /s /t 0

echo [1.6] taskkill
taskkill /F /IM notepad.exe

echo [1.7] reg add
reg add HKCU\TestKey

echo [1.8] net user
net user

echo.
echo ============================================================
echo  SECTION 2: Caret (^) insertion bypass (BLIND SPOT expected)
echo  cmd strips ^ before dispatch; hook sees raw line pre-strip.
echo ============================================================

echo [2.1] d^el - caret inside token
d^el test_file.txt

echo [2.2] r^d - caret inside token
r^d test_dir

echo [2.3] task^kill - caret inside token
task^kill /F /IM notepad.exe

echo [2.4] shutdown /^s - caret inside flag
shutdown /^s /t 0

echo.
echo ============================================================
echo  SECTION 3: Chained operators (BLOCK expected)
echo  Tokenizer splits on & | && || -- blocked token is still
echo  first token of its segment.
echo ============================================================

echo [3.1] echo ^& del (& separator)
echo hello & del test_file.txt

echo [3.2] echo ^&^& del (&& separator)
echo hello && del test_file.txt

echo [3.3] echo ^|^| del (|| separator)
echo hello || del test_file.txt

echo [3.4] del ^& echo (blocked first, then echo)
del test_file.txt & echo done

echo [3.5] del ^| findstr (pipe after del)
del test_file.txt | findstr x

echo [3.6] three chained: echo ^& echo ^& del
echo a & echo b & del test_file.txt

echo [3.7] rmdir ^& echo
rmdir test_dir & echo removed

echo [3.8] shutdown ^&^& echo
shutdown /s /t 0 && echo bye

echo [3.9] net ^| findstr
net user | findstr Administrator

echo [3.10] taskkill ^&^& echo
taskkill /F /IM notepad.exe && echo killed

echo.
echo ============================================================
echo  SECTION 4: Redirection (BLOCK expected)
echo  Redirects don't affect the command token.
echo ============================================================

echo [4.1] del redirected to nul
del test_file.txt > nul

echo [4.2] del with stderr redirect
del test_file.txt 2>&1

echo [4.3] del with both redirected
del test_file.txt > nul 2>&1

echo [4.4] rmdir redirected
rmdir test_dir > nul

echo [4.5] shutdown redirected
shutdown /s /t 0 > nul 2>&1

echo.
echo ============================================================
echo  SECTION 5: Quoted command token (BLIND SPOT expected)
echo  CmdLineTokenizer enters IN_QUOTE on leading " and never
echo  records a command token -- false negative.
echo ============================================================

echo [5.1] "del" quoted
"del" test_file.txt

echo [5.2] "rmdir" quoted
"rmdir" test_dir

echo [5.3] "shutdown" quoted
"shutdown" /s /t 0

echo [5.4] "taskkill" quoted
"taskkill" /F /IM notepad.exe

echo [5.5] "reg" quoted
"reg" add HKCU\TestKey

echo.
echo ============================================================
echo  SECTION 6: Environment variable expansion (BLIND SPOT)
echo  Tokenizer sees unexpanded form; expansion is runtime-only.
echo ============================================================

echo [6.1] %c% where c=del
set c=del
%c% test_file.txt

echo [6.2] split across two vars
set cm=d
set cm2=el
%cm%%cm2% test_file.txt

echo [6.3] %COMSPEC% /c del
%COMSPEC% /c del test_file.txt

echo [6.4] %SystemRoot% full path shutdown
%SystemRoot%\System32\shutdown.exe /s /t 0

echo.
echo ============================================================
echo  SECTION 7: Full path invocations (BLIND SPOT for cmd layer)
echo  Basename extraction in CreateProcessW hook should catch these
echo  at Layer 4; cmd builtin hooks won't see them.
echo ============================================================

echo [7.1] full path cmd.exe /c del
C:\Windows\System32\cmd.exe /c del test_file.txt

echo [7.2] full path shutdown.exe
C:\Windows\System32\shutdown.exe /s /t 0

echo [7.3] full path taskkill.exe
C:\Windows\System32\taskkill.exe /F /IM notepad.exe

echo [7.4] full path reg.exe
C:\Windows\System32\reg.exe add HKCU\TestKey

echo [7.5] full path net.exe
C:\Windows\System32\net.exe user

echo.
echo ============================================================
echo  SECTION 9: requiresFlag rules (ALLOW / BLOCK mixed)
echo  ping alone = ALLOW; ping -t = BLOCK
echo  sc alone = depends; sc create / sc delete = BLOCK
echo ============================================================

echo [9.1] ping without -t (ALLOW)
ping 127.0.0.1

echo [9.2] ping -t (BLOCK)
ping -t 127.0.0.1

echo [9.3] ping -n 4 (ALLOW)
ping -n 4 127.0.0.1

echo [9.4] sc query (ALLOW)
sc query

echo [9.5] sc create (BLOCK)
sc create MySvc binPath= "C:\test.exe"

echo [9.6] sc delete (BLOCK)
sc delete MySvc

echo.
echo ============================================================
echo  SECTION 10: cmd /c passthrough to CreateProcessW (BLOCK)
echo  These reach Layer 4 and CmdConsole location both.
echo ============================================================

echo [10.1] cmd /c del
cmd /c del test_file.txt

echo [10.2] cmd /c "del" (quoted payload)
cmd /c "del test_file.txt"

echo [10.3] cmd /c rmdir
cmd /c rmdir test_dir

echo [10.4] cmd /c shutdown
cmd /c shutdown /s /t 0

echo [10.5] cmd /k del
cmd /k del test_file.txt

echo [10.6] cmd /c del ^& echo (chained payload)
cmd /c del test_file.txt & echo done

echo [10.7] cmd /c net user
cmd /c net user

echo [10.8] cmd /c taskkill
cmd /c taskkill /F /IM notepad.exe

echo.
echo ============================================================
echo  All cmd sections complete.
echo  Check poc-host.exe output for BLOCK/ALLOW per command.
echo ============================================================