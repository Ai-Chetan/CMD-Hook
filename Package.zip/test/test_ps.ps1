# =============================================================================
#  test_ps.ps1 -- AMSI layer tests for poc-command-restriction
#  Run section by section in an interactive PS session with poc-host.exe live.
#  Paste individual sections to avoid the whole-script AMSI scan blocking early.
# =============================================================================

Write-Host ""
Write-Host "============================================================"
Write-Host " SECTION 1: Direct blocked cmdlets (BLOCK expected)"
Write-Host "============================================================"

Write-Host "[1.1] Remove-Item no flags (ALLOW)"
Remove-Item "test_file.txt"

Write-Host "[1.2] Remove-Item -Recurse (BLOCK)"
Remove-Item "test_dir" -Recurse

Write-Host "[1.3] Remove-Item -Force (BLOCK)"
Remove-Item "test_file.txt" -Force

Write-Host "[1.4] Invoke-Expression (BLOCK)"
Invoke-Expression "Write-Host hi"

Write-Host "[1.5] Invoke-WebRequest (BLOCK)"
Invoke-WebRequest "http://example.com"

Write-Host "[1.6] Invoke-RestMethod (BLOCK)"
Invoke-RestMethod "http://example.com"

Write-Host "[1.7] Start-BitsTransfer (BLOCK)"
Start-BitsTransfer -Source "http://example.com/f" -Destination "C:\f"

Write-Host "[1.8] Stop-Computer (BLOCK)"
Stop-Computer

Write-Host "[1.9] Restart-Computer (BLOCK)"
Restart-Computer

Write-Host "[1.10] Stop-Process (BLOCK)"
Stop-Process -Name "notepad"

Write-Host "[1.11] Clear-EventLog (BLOCK)"
Clear-EventLog -LogName "Application"

Write-Host "[1.12] Remove-EventLog (BLOCK)"
Remove-EventLog -Source "TestSource"

Write-Host "[1.13] Set-ExecutionPolicy (BLOCK)"
Set-ExecutionPolicy -ExecutionPolicy Bypass

Write-Host "[1.14] New-ScheduledTask (BLOCK)"
New-ScheduledTask -TaskName "T"

Write-Host "[1.15] Register-ScheduledTask (BLOCK)"
Register-ScheduledTask -TaskName "T" -InputObject $null

Write-Host "[1.16] Add-MpPreference (BLOCK)"
Add-MpPreference -ExclusionPath "C:\test"

Write-Host "[1.17] Set-MpPreference (BLOCK)"
Set-MpPreference -DisableRealtimeMonitoring $true

Write-Host "[1.18] Disable-NetFirewallRule (BLOCK)"
Disable-NetFirewallRule -Name "TestRule"

Write-Host ""
Write-Host "============================================================"
Write-Host " SECTION 2: Aliases (BLOCK expected)"
Write-Host "============================================================"

Write-Host "[2.1] iex"
iex "Write-Host hi"

Write-Host "[2.2] irm"
irm "http://example.com"

Write-Host "[2.3] wget"
wget "http://example.com"

Write-Host "[2.4] curl"
curl "http://example.com"

Write-Host "[2.5] kill"
kill -Name "notepad"

Write-Host "[2.6] spps"
spps -Name "notepad"

Write-Host ""
Write-Host "============================================================"
Write-Host " SECTION 3: requiresFlag -- same statement (BLOCK expected)"
Write-Host "============================================================"

Write-Host "[3.1] Remove-Item alone (ALLOW)"
Remove-Item "test_file.txt"

Write-Host "[3.2] Remove-Item -Recurse (BLOCK)"
Remove-Item "test_dir" -Recurse

Write-Host "[3.3] Remove-Item -Force (BLOCK)"
Remove-Item "test_file.txt" -Force

Write-Host "[3.4] Remove-Item -Recurse -Force both (BLOCK)"
Remove-Item "test_file.txt" -Recurse -Force

Write-Host "[3.5] New-Item alone (ALLOW)"
New-Item "C:\testpath"

Write-Host "[3.6] New-Item -Force (BLOCK)"
New-Item "C:\testpath" -Force

Write-Host "[3.7] New-Item -ItemType -Force (BLOCK)"
New-Item "C:\testpath" -ItemType Directory -Force

Write-Host "[3.8] Set-ItemProperty alone (ALLOW)"
Set-ItemProperty -Path "HKCU:\Software\Test" -Name "Val" -Value 1

Write-Host "[3.9] Set-ItemProperty -Force (BLOCK)"
Set-ItemProperty -Path "HKCU:\Software\Test" -Name "Val" -Value 1 -Force

Write-Host "[3.10] Move-Item alone (ALLOW)"
Move-Item "a.txt" "b.txt"

Write-Host "[3.11] Move-Item -Force (BLOCK)"
Move-Item "a.txt" "b.txt" -Force

Write-Host ""
Write-Host "============================================================"
Write-Host " SECTION 4: requiresFlag -- cross-segment (ALLOW expected)"
Write-Host " Flag is on a different pipeline segment than the command."
Write-Host " Must NOT trigger co-occurrence rule."
Write-Host "============================================================"

Write-Host "[4.1] Get-ChildItem -Recurse | Remove-Item (ALLOW)"
Get-ChildItem -Recurse | Remove-Item

Write-Host "[4.2] Get-ChildItem -Recurse ; Remove-Item (ALLOW ; ALLOW)"
Get-ChildItem -Recurse; Remove-Item "test.txt"

Write-Host "[4.3] left segment has -Force, right is plain Remove-Item (ALLOW)"
Get-Item "test.txt" -Force | Remove-Item

Write-Host ""
Write-Host "============================================================"
Write-Host " SECTION 5: Chaining -- flag co-occurs on correct segment"
Write-Host "============================================================"

Write-Host "[5.1] Write-Host ; Remove-Item -Recurse (ALLOW ; BLOCK)"
Write-Host "before"; Remove-Item "test.txt" -Recurse

Write-Host "[5.2] Write-Host ; Remove-Item (ALLOW ; ALLOW)"
Write-Host "before"; Remove-Item "test.txt"

Write-Host "[5.3] pipe into Remove-Item -Force (BLOCK on right)"
Get-Item "test.txt" | Remove-Item -Force

Write-Host "[5.4] pipe into Remove-Item -Recurse (BLOCK on right)"
Get-Item "test.txt" | Remove-Item -Recurse

Write-Host "[5.5] three segments: Write-Host ; Write-Host ; Remove-Item -Force"
Write-Host "a"; Write-Host "b"; Remove-Item "test.txt" -Force

Write-Host ""
Write-Host "============================================================"
Write-Host " SECTION 6: Backtick obfuscation (BLIND SPOT candidates)"
Write-Host " PS strips backtick before AMSI in most hosts."
Write-Host "============================================================"

Write-Host "[6.1] Inv``oke-Expression"
Inv`oke-Expression "Write-Host hi"

Write-Host "[6.2] Rem``ove-Item -Recurse"
Rem`ove-Item "test.txt" -Recurse

Write-Host "[6.3] Stop-Com``puter"
Stop-Com`puter

Write-Host "[6.4] i``ex (alias + backtick)"
i`ex "Write-Host hi"

Write-Host "[6.5] Invoke-W``ebRequest multiple backticks"
Invoke-W`ebR`equest "http://example.com"

Write-Host ""
Write-Host "============================================================"
Write-Host " SECTION 7: Case variation (BLOCK expected)"
Write-Host " Tokenizer lowercases before matching."
Write-Host "============================================================"

Write-Host "[7.1] REMOVE-ITEM -RECURSE"
REMOVE-ITEM "test.txt" -RECURSE

Write-Host "[7.2] Remove-item -recurse"
Remove-item "test.txt" -recurse

Write-Host "[7.3] INVOKE-EXPRESSION"
INVOKE-EXPRESSION "Write-Host hi"

Write-Host "[7.4] IEX"
IEX "Write-Host hi"

Write-Host "[7.5] Iex mixed case"
Iex "Write-Host hi"

Write-Host "[7.6] STOP-COMPUTER"
STOP-COMPUTER

Write-Host "[7.7] Stop-computer"
Stop-computer

Write-Host ""
Write-Host "============================================================"
Write-Host " SECTION 8: Tokens in data position (ALLOW expected)"
Write-Host " Regression guard -- must not false-positive."
Write-Host "============================================================"

Write-Host "[8.1] Get-Command Remove-Item (argument position)"
Get-Command Remove-Item

Write-Host "[8.2] Get-Help Invoke-Expression (argument position)"
Get-Help Invoke-Expression

Write-Host "[8.3] Get-Help iex"
Get-Help iex

Write-Host "[8.4] string variable holding blocked name"
$x = "Remove-Item"

Write-Host "[8.5] array of blocked names as data"
$arr = @("Remove-Item", "iex", "Stop-Computer")

Write-Host "[8.6] Write-Host with blocked names as argument"
Write-Host "Remove-Item Stop-Computer iex"

Write-Host "[8.7] Import-Module (triggers manifest load -- ALLOW)"
Import-Module Microsoft.PowerShell.Management

Write-Host ""
Write-Host "============================================================"
Write-Host " SECTION 9: Quoted strings (ALLOW expected)"
Write-Host "============================================================"

Write-Host "[9.1] single-quoted blocked name"
$a = 'Remove-Item'

Write-Host "[9.2] double-quoted blocked name"
$b = "Invoke-Expression"

Write-Host "[9.3] all blocked inside Write-Host string"
Write-Host 'iex Remove-Item Stop-Computer Invoke-WebRequest'

Write-Host "[9.4] here-string"
$h = @'
Remove-Item test.txt -Recurse
Invoke-Expression hi
'@

Write-Host ""
Write-Host "============================================================"
Write-Host " SECTION 10: Comment lines (ALLOW expected)"
Write-Host "============================================================"

Write-Host "[10.1] full-line comment with blocked token"
# Remove-Item test.txt -Recurse

Write-Host "[10.2] inline comment with blocked token"
$y = 1  # Stop-Computer

Write-Host "[10.3] inline comment with alias"
$z = 2  # iex "hi"

Write-Host ""
Write-Host "============================================================"
Write-Host " SECTION 11: Variable-assembled commands (BLIND SPOT)"
Write-Host "============================================================"

Write-Host "[11.1] call operator & with variable (BLIND SPOT)"
$cmd = "Remove-Item"
& $cmd "test.txt" -Recurse

Write-Host "[11.2] iex with concatenated string (BLOCK -- iex caught)"
$payload = "Remove-" + "Item test.txt -Recurse"
iex $payload

Write-Host "[11.3] ScriptBlock::Create then invoke (BLIND SPOT)"
$sb = [scriptblock]::Create("Remove-Item test.txt -Recurse")
& $sb

Write-Host ""
Write-Host "============================================================"
Write-Host " SECTION 12: .NET reflection bypass (BLIND SPOT)"
Write-Host " No cmdlet involved -- AMSI token rules cannot catch these."
Write-Host "============================================================"

Write-Host "[12.1] System.IO.File::Delete"
[System.IO.File]::Delete("test_file.txt")

Write-Host "[12.2] System.IO.Directory::Delete recursive"
[System.IO.Directory]::Delete("test_dir", $true)

Write-Host "[12.3] Process.Kill via reflection"
[System.Diagnostics.Process]::GetProcessesByName("notepad") | ForEach-Object { $_.Kill() }

Write-Host ""
Write-Host "============================================================"
Write-Host " SECTION 13: blocked.txt POC validation token"
Write-Host "============================================================"

Write-Host "[13.1] blocked.txt in command position (BLOCK)"
blocked.txt

Write-Host "[13.2] blocked.txt as variable value (ALLOW)"
$x = "blocked.txt"

Write-Host "[13.3] blocked.txt as argument to Write-Host (ALLOW)"
Write-Host "blocked.txt"

Write-Host "[13.4] Remove-Item blocked.txt -- token in arg position (ALLOW)"
Remove-Item "blocked.txt"

Write-Host ""
Write-Host "============================================================"
Write-Host " All sections complete."
Write-Host " Check poc-host.exe output and poc-amsi-debug.log."
Write-Host "============================================================"